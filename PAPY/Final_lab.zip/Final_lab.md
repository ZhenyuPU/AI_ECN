---
author: Lucas Lestandi
year: 2023
title: "Final Lab: Visualizing France 2022 Weather"
license: BSD
include-heading:
- \usepackage{graphicx}
geometry:
- top=20mm
- left=20mm
- heightrounded
---

# Visualizing France 2022 Weather

> As a data scientist, you are tasked by a newspaper to prepare 2 striking visuals to support an article about 2022 weather in France.

**Goal:** During this lab, you will prepare 2 general public data visualization **with** interpretation/story to create a clear and efficient communication tool.

**Topic:** You have discovered the curated weather dataset  `weather2022.geojson` in the python lab. It is a slightly curated version of the open record found at [MétéoFrance](https://public.opendatasoft.com/explore/dataset/donnees-synop-essentielles-omm/export/).

**Software:** You will use any software you deem fit to conduct extra investigation and/or generate your definitive visuals.

**Duration:** 4h. 

**Report:**

- Present the dataset and your understanding of it
- Explain what data analysis/exploration you have done. Feel free to manipulate the data and extract/compute information from the set.
- Show inspiration sources you have used (if any)
- Show your draft version(s), including a hand-drawn graph layout
- Write a storyboard
- Describe building steps of each of your visuals
- Show each of your visuals on a separate page.

**Remarks:** 

1. The visuals may contain subplots, text or any visual cue that will help the reader understand your point!
2. Before you commit to a visual, please check with the instructor for green light. 

**Grading:**

- groups of two
- this has to be original work
- 30% of the total grade


If you have difficulties with these, please reach out to the instructor.

# Ouest France Newspaper editors pitch
*"We are preparing an article about the weather observed in France (mainland and overseas territories). In order to help our journalists to write a striking article, you need to produce two visuals.*

*The first one will be about the heatwave that occurred between 14 and 19 July and particularly focusing on Brittany and Pays de la Loire.*

*Next, our writers need a bit of help for inspiration, please dig out some nice facts in `weather2022.geojson`, any of the following items may be of interest:*

- Extreme events (temp, wind, pressure)
- Drought conditions leading to wildfires
- any region left unscathed
- Focus on a given city
- overseas territories
- any observation of your own
  
**You can get a record of historical weather at all the stations in the dataset at [www.infoclimat.fr](www.infoclimat.fr) e.g for Nantes https://www.infoclimat.fr/climatologie/globale/nantes-atlantique/07222.html**.
