from setuptools import setup, find_packages

setup(
    name="Mandelbrot_Julia_Plot",
    version="1.0",
    author="Zhenyu PU",
    packages=find_packages(),
)