alias MandelbrotPlot='python -m Mandelbrot_Julia_Plot MandelbrotPlot'

alias JuliaPlot='python -m Mandelbrot_Julia_Plot/__main__.py JuliaPlot'