Mandelbrot\_Julia\_Plot package
===============================

Submodules
----------

Mandelbrot\_Julia\_Plot.TP module
---------------------------------

.. automodule:: Mandelbrot_Julia_Plot.TP
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: Mandelbrot_Julia_Plot
   :members:
   :undoc-members:
   :show-inheritance:
