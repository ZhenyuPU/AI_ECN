.. Mandelbrot_Julia_Plot documentation master file, created by
   sphinx-quickstart on Fri Oct 27 11:19:52 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Mandelbrot_Julia_Plot's documentation!
=================================================
.. note::
   :class: custom

   This is a documentation for Mandelbrot_Julia_Plot, which is a python project for generating Mandelbrot and Julia set images.
   You can find details in following contents including the description of documentation and module details.

.. toctree::
   :maxdepth: 4
   :caption: Contents:
   
   README
   Mandelbrot_Julia_Plot



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
