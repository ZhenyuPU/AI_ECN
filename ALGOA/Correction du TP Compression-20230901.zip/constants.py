# TP ALGOA : compression bzip
# Didier Lime, novembre 2022
#
# Tous droits réservés

block_size = 500000
bwt_marker = 256
rle_one = 257
rle_two = 258
huffman_marker = 259
